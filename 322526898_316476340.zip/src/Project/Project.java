//Amir Malikson 322526898
//Ido Elmakies 316476340

package Project;
import Student.Student;

public interface Project {
	void add(Student newStudent);
	void remove(Student existsStudent);
	void update();
	String getName();
	String getStatus();
	void setStatus(String newStatus);
}
