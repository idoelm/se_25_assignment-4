//Amir Malikson 322526898
//Ido Elmakies 316476340

public class Car {
	CarType _type;
	double _km;
	int _prevOwners;
	int _year;
	boolean _isCab;
    double dieselValue = 0;
    int basicDiesel = 100000;
    int maxYearsDiesel = 20;
    double MinValuePercentDiesel = 0.1;
    
    double hybridValue = 0;
    int basicHybrid = 120000;
    int maxYearsHybrid = 10;
    double MinValuePercentHybrid = 0.2;
    
	public Car(CarType type, int year) {
		_type=type;
		_km=0;
		_prevOwners=0;
		_year=year;
		_isCab=false;
	}
	
	public double CalculatingValue(int basicDiesel, int curYear, int year, int maxYears,double minPercent)
	{
	    return (basicDiesel * Math.max((maxYears-(curYear-year))/maxYears,minPercent));
	}
	
	public double getValue(int curYear) {
		double x,y=0;
		switch(_type) {
		case DESIL:
			dieselValue = CalculatingValue(basicDiesel, curyear,_year, maxYearsHybrid, MinValuePercentHybrid);
			if(_isCab) {
				y= dieselValue * 0.5 ;
			} else {
				y = Math.max(dieselValue * 0.1, dieselValue + dieselValue * 0.1 * ((20000 - _km / (curYear - _year + 1)) / 20000));
			}
			break;
		case HYBRID:
			hybridValue = CalculatingValue(basicHybrid, curyear,_year, maxYearsDiesel, MinValuePercentDiesel);
			y = (Math.max(100000-_km,0)/100000) * hybridValue; 
			y = hybridValue *Math.max(3 - _prevOwners,3)/3 + y + 2500;
			y = Math.max(hybridValue * 0.2, y);
			break;
		}
		y = Math.max(0, y);
		return y;
	}