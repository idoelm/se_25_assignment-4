//Amir Malikson 322526898
//Ido Elmakies 316476340

public class Car {
	CarType _type;
	double _km;
	int _prevOwners;
	int _year;
	boolean _isCab;
    double dieselValue = 0;
    double hybridValue = 0;
    int basicDiesel = 100000;
    int basicHybrid = 120000;
    
	public Car(CarType type, int year) {
		_type=type;
		_km=0;
		_prevOwners=0;
		_year=year;
		_isCab=false;
	}
	
	public double CalculatingValue(int basicDiesel, int curYear, int year)
	{
	    return (basicDiesel * Math.max((20-(curYear-year))/20,0.1));
	}
	
	public double getValue(int curYear) {
		double x,y=0;
		switch(_type) {
		case DESIL:
			dieselValue = CalculatingValue(basicDiesel, curyear,_year);
			if(_isCab) {
				y= dieselValue * 0.5 ;
			} else {
				y = Math.max(dieselValue * 0.1, dieselValue + dieselValue * 0.1 * ((20000 - _km / (curYear - _year + 1)) / 20000));
			}
			break;
		case HYBRID:
			hybridValue = 120000 * Math.max((10-(curYear-_year))/10,0.2);
			y = (Math.max(100000-_km,0)/100000) * hybridValue; 
			y = hybridValue *Math.max(3 - _prevOwners,3)/3 + y + 2500;
			y = Math.max(hybridValue * 0.2, y);
			break;
		}
		y = Math.max(0, y);
		return y;
	}