//Amir Malikson 322526898
//Ido Elmakies 316476340

package Student;
import Project.Project;

public class smsStudent implements Student{
	
	private String name;
	
	public smsStudent(String myName)
	{
		this.name = myName;
	}
	
	public void update(Project project)
	{
		System.out.println("SMS message from the projects system: Hello " + this.name + ", the update is: " + project.getName() + " now in " + project.getStatus());
	}

}
