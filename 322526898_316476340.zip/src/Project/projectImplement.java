//Amir Malikson 322526898
//Ido Elmakies 316476340

package Project;

import java.util.ArrayList;
import java.util.List;

import Student.Student;

public class projectImplement implements Project{
	private String name;
	private List<Student> studentList;
	private String status;
	
	public projectImplement(String myName)
	{
		this.name = myName;
		this.studentList = new ArrayList<>();
		this.status = "open";
	}
	
	public String getName()
	{
		return this.name;
	}
	public String getStatus()
	{
		return this.status;
	}
	
	public void add(Student newStudent)
	{
		this.studentList.add(newStudent);
	}
	public void remove(Student existsStudent)
	{
		this.studentList.remove(existsStudent);
	}
	public void update()
	{
		for(Student student : studentList)
		{
			student.update(this);
		}
		System.out.println("--------------------------------------------");
	}
	public void setStatus(String newStatus)
	{
		this.status = newStatus;
		this.update();
	}


}
