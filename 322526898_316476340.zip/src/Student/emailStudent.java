//Amir Malikson 322526898
//Ido Elmakies 316476340

package Student;
import Project.Project;

public class emailStudent implements Student{
	
	private String name;
	
	public emailStudent(String myName)
	{
		this.name = myName;
	}
	
	public void update(Project project)
	{
		System.out.println("EMAIL message from the projects system: Hello " + this.name + ", the update is: " + project.getName() + " now in " + project.getStatus());
	}
}
