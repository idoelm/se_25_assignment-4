import Project.Project;
import Project.projectImplement;
import Student.Student;
import Student.emailStudent;
import Student.smsStudent;

public class system {

	public static void main(String[] args) {
		
		Project p1 = new projectImplement("Facebook");
		Project p2 = new projectImplement("wobi");
		
		Student s1 = new emailStudent("David");
		Student s2 = new smsStudent("Yosef");
		Student s3 = new emailStudent("Shimon");
		Student s4 = new smsStudent("Levi");
		
		p1.add(s1);
		p1.add(s2);
		p2.add(s3);
		p2.add(s4);
		
		p1.update();
		p2.update();
		
		p1.setStatus("In development");
		p2.setStatus("closed");
		
	}

}
