//Amir Malikson 322526898
//Ido Elmakies 316476340

package Student;
import Project.Project;

public interface Student {
	void update(Project project);

}
